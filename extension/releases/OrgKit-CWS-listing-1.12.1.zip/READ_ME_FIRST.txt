OrgKit 1.12.1 — Chrome Web Store resubmit pack
=================================================

1) Package
   Upload 1-UPLOAD-THIS/OrgKit-store.zip
   (manifest.json is at the zip root. Version 1.12.1.)

2) Store icon
   2-GRAPHICS/store-icon-128.png
   Abstract K on a dark tile. Replace any leftover blue OK / briefcase icon.

3) Screenshots (1280×800) — upload in this order
   01-home, 02-query, 03-schema, 04-compare
   05-launcher is optional (dark OrgKit edge tab on a Salesforce page).
   Do not keep old light-theme screenshots in the listing.

4) Promo tiles — replace the old light Lightning tiles
   small-promo-440x280.png
   marquee-promo-1400x560.png

5) Paste from 3-PASTE/
   LISTING_COPY.txt              short + detailed + single purpose
   PERMISSION_JUSTIFICATIONS.txt cookies / storage / tabs / hosts
   PRIVACY_QUESTIONNAIRE.txt     data safety answers
   REVIEWER_NOTES.txt            reviewer notes field
   STORE_LISTING_URLS.txt        homepage / support / privacy

6) Before Submit for review
   Incognito-check:
     https://rajeevketha.github.io/orgkit/
     https://rajeevketha.github.io/orgkit/privacy.html
   Homepage must say Query / Schema / Compare / Apex (not Session Workbench).
